package mydawg.project.mydawgandroid.models;

import mydawg.project.mydawgandroid.MainActivity;

public class MyFoodRegister extends MainActivity
{
    //Variables
    private String brand, store, flavour, dateOfPurchase, dateOfOpening, quantity, amountADay, price;

    //Default constructor
    public MyFoodRegister()
    {

    }

    //constructor with parameters
    public MyFoodRegister(String brand, String store, String flavour, String dateOfPurchase,
                          String dateOfOpening, String quantity, String amountADay, String price)
    {
        this.brand = brand;
        this.store = store;
        this.flavour = flavour;
        this.dateOfPurchase = dateOfPurchase;
        this.dateOfOpening = dateOfOpening;
        this.quantity = quantity;
        this.amountADay = amountADay;
        this.price = price;
    }

    //Getters and Setters
    public String getBrand()
    {
        return brand;
    }

    public void setBrand(String brand)
    {
        this.brand = brand;
    }

    public String getStore()
    {
        return store;
    }

    public void setStore(String store)
    {
        this.store = store;
    }

    public String getFlavour()
    {
        return flavour;
    }

    public void setFlavour(String flavour)
    {
        this.flavour = flavour;
    }

    public String getDateOfPurchase()
    {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(String dateOfPurchase)
    {
        this.dateOfPurchase = dateOfPurchase;
    }

    public String getDateOfOpening()
    {
        return dateOfOpening;
    }

    public void setDateOfOpening(String dateOfOpening)
    {
        this.dateOfOpening = dateOfOpening;
    }

    public String getQuantity()
    {
        return quantity;
    }

    public void setQuantity(String quantity)
    {
        this.quantity = quantity;
    }

    public String getAmountADay()
    {
        return amountADay;
    }

    public void setAmountADay(String amountADay)
    {
        this.amountADay = amountADay;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price)
    {
        this.price = price;
    }
}
